#include <Arduino.h>
//### I2C COMMUNICATION
#include <Wire.h>
//### SPI COMMUNICATION (needed for inner workings of IMU libraries)
#include <SPI.h>


//### MICRO-ROS
#include <micro_ros_platformio.h>
#include <rcl/rcl.h>
#include <rclc/rclc.h>
#include <rclc/executor.h>
#include <rmw_microros/rmw_microros.h>

  //### CUSTOM ROS MESSAGES
#include <traxter_msgs/msg/dual_motor_array.h>
#include <traxter_msgs/msg/light_imu.h>

//### CUSTOM MD25 LIBRARY
#include <MD25IIC.h>
//### BNO055 IMU LIBRARY
#include <Adafruit_Sensor.h>
#include <Adafruit_BNO055.h>
#include <utility/imumaths.h>

  //MD25
MD25IIC MD25;
enum MD25_Status {DISCONNECTED, CONNECTED};
enum Encoder_Status {ZEROED, OPERATIONAL};
bool isMD25connected=false;
bool encoder_reset_asked=false;

  //BNO055 IMU
Adafruit_BNO055 bno = Adafruit_BNO055(55, 0x28);
bool isIMUconnected=false;
sensors_event_t angVelocityData , linearAccelData;

  //MICRO-ROS
    //general
rclc_support_t support;
rcl_allocator_t allocator;
rcl_node_t node;
    //encoder ticks stuff
rcl_publisher_t enconderTicks_publisher;
traxter_msgs__msg__DualMotorArray encoderTicks_msg;
rcl_timer_t encoderTicks_and_imu_timer;
rclc_executor_t encoderTicks_and_imu_executor;
    //imu stuff
rcl_publisher_t imu_publisher;
traxter_msgs__msg__LightImu imu_msg;
    //motor commands stuff
rcl_subscription_t motorCommand_subscriber;
traxter_msgs__msg__DualMotorArray motorCommand_msg;
traxter_msgs__msg__DualMotorArray previous_motorCommand_msg;
rclc_executor_t motorCommand_executor;

  //miscellaneous
uint8_t RED_PIN=17;
uint8_t GREEN_PIN=18;
uint8_t BLUE_PIN=19;
bool stopped_from_moving=false;
uint8_t cycles_no_message=0;
uint8_t number_of_problems=0;
const uint16_t minimum_speed=100; //x100
bool whichEncoderFirst=true;
bool whichMotorFirst=true;

//if any of the micro-ros things is not successfully created, then reboot
#define RCCHECK(fn) { rcl_ret_t temp_rc = fn; if((temp_rc != RCL_RET_OK)){start_over();}}
//if more than 35 problems occur while spinning, then reboot
#define RCSOFTCHECK(fn) { rcl_ret_t temp_rc = fn; if((temp_rc != RCL_RET_OK)){number_of_problems++;if(number_of_problems>35){start_over();}}else{number_of_problems--;}}



/////////// Lighting
void RGB_color(uint8_t red_light_value, uint8_t green_light_value, uint8_t blue_light_value)
 {
  analogWrite(RED_PIN, red_light_value);
  analogWrite(GREEN_PIN, green_light_value);
  analogWrite(BLUE_PIN, blue_light_value);
}

void illuminate(){

if (stopped_from_moving && isMD25connected)
{
  RGB_color(255,255,0); //YELLOW
  return;
}
else if(stopped_from_moving && !isMD25connected)
{
  RGB_color(0,0,255); //BLUE
  return;
}
else if(!stopped_from_moving && !isMD25connected)
{
  RGB_color(255,50,255); //MAGENTA
  return;

}else{
  RGB_color(0,255,0); //GREEN
  return;
}
}
///////////

/////////// Emergency Stop
void stop_moving(){
  MD25.setMotor1Speed(0);   // The motor is stoped
  MD25.setMotor2Speed(0);   // The motor is stoped
  stopped_from_moving=true;
}
///////////

/////////// MD25 settings/initialization
void setupMD25(){
  MD25.enableTimeOut(true);  // Enable automatic 2s timeout
  MD25.enableController(true);// Enable on-board feedback speed control
  MD25.setMode(1);  //Set mode -128-127
  MD25.setAcceleration(5);   // Increase acceleration (default = 5)
  stop_moving();
  MD25.resetEncoders();       // Initialize to zero the encoder register
}
///////////

/////////// MPU settings/initialization
void setupIMU(){
    /* Initialise the sensor */
  if (!bno.begin())
  {
    imu_msg.acc_status=255;
    imu_msg.gyro_status=255;
    imu_msg.mag_status=255;
    return;
  }
  isIMUconnected=true;
  bno.setExtCrystalUse(true);
  delay(10);
}
///////////

/////////// Reboot
void start_over(){
RGB_color(255,0,0);//red light
stop_moving();
  //close everything
rcl_ret_t rc=rcl_publisher_fini(&enconderTicks_publisher, &node);
rc=rcl_publisher_fini(&imu_publisher, &node);
rc=rcl_subscription_fini(&motorCommand_subscriber, &node);
rc=rclc_executor_fini(&motorCommand_executor);
rc=rclc_executor_fini(&encoderTicks_and_imu_executor);
rc=rcl_timer_fini(&encoderTicks_and_imu_timer);
rc=rcl_node_fini(&node);
rclc_support_fini(&support);
traxter_msgs__msg__DualMotorArray__fini(&encoderTicks_msg);
traxter_msgs__msg__DualMotorArray__fini(&motorCommand_msg);
traxter_msgs__msg__LightImu__fini(&imu_msg);
delay(1000);
esp_restart();//reboot
}
///////////

/////////// publish imu callback
void imu_callback(){
    if(isIMUconnected){
      imu::Quaternion quat = bno.getQuat();
      uint8_t system, gyro, accel, mag = 0;
      bno.getCalibration(&system, &gyro, &accel, &mag);
      bno.getEvent(&angVelocityData, Adafruit_BNO055::VECTOR_GYROSCOPE);
      bno.getEvent(&linearAccelData, Adafruit_BNO055::VECTOR_ACCELEROMETER);
      /* bno.getEvent(&linearAccelData, Adafruit_BNO055::VECTOR_LINEARACCEL); */
      imu_msg.q1=int(quat.x()*100.0);//100x the value
      imu_msg.q2=int(quat.y()*100.0);
      imu_msg.q3=int(quat.z()*100.0);
      imu_msg.q0=int(quat.w()*100.0);
      imu_msg.acc_status=accel;
      imu_msg.gyro_status=gyro;
      imu_msg.mag_status=mag;
      imu_msg.gyrox=int(angVelocityData.gyro.x*100.0);
      imu_msg.gyroy=int(angVelocityData.gyro.y*100.0);
      imu_msg.gyroz=int(angVelocityData.gyro.z*100.0);
      imu_msg.accx=int(linearAccelData.acceleration.x*100.0);
      imu_msg.accy=int(linearAccelData.acceleration.y*100.0);
      imu_msg.accz=int(linearAccelData.acceleration.z*100.0);
    }
}
///////////
void md25_callback(){
    if (!isMD25connected){
      setupMD25();
      encoderTicks_msg.motor1=0;
      encoderTicks_msg.motor2=0;
      encoderTicks_msg.status=Encoder_Status::ZEROED;
    }else{
      if(encoder_reset_asked){
        MD25.resetEncoders();
        encoderTicks_msg.motor1=0;
        encoderTicks_msg.motor2=0;
        encoderTicks_msg.status=Encoder_Status::ZEROED;
        encoder_reset_asked=false;
      }else{
        if(whichEncoderFirst){
          encoderTicks_msg.motor1=MD25.getMotor1Encoder();
          encoderTicks_msg.motor2=MD25.getMotor2Encoder();
          whichEncoderFirst=false;
        }else{
          encoderTicks_msg.motor2=MD25.getMotor2Encoder();
          encoderTicks_msg.motor1=MD25.getMotor1Encoder();
          whichEncoderFirst=true;          
        }
        encoderTicks_msg.status=Encoder_Status::OPERATIONAL;
      }
    }
}
////////////////////////////////////

/////////// publish encoder ticks callback
void encoderTicks_and_imu_timer_callback(rcl_timer_t * encoderTicks_and_imu_timer, int64_t pub_last_call_time) {
  RCLC_UNUSED(pub_last_call_time);
  if (encoderTicks_and_imu_timer != NULL) {
    md25_callback();
    imu_callback();
    RCSOFTCHECK(rcl_publish(&enconderTicks_publisher, &encoderTicks_msg, NULL));
    RCSOFTCHECK(rcl_publish(&imu_publisher, &imu_msg, NULL));
  }
}
///////////

/////////// motor command subscription
void motorCommand_subscriber_callback(const void * msgin){
  const traxter_msgs__msg__DualMotorArray * msg = (const traxter_msgs__msg__DualMotorArray *)msgin;
  if (msg != NULL) {
    float voltage_available=MD25.getBattery()/10.0 +0.001;//x10 (epsilon to avoid seg fault)

    int max_speed_possible = int((voltage_available*1.9158-1.0691)+0.5)*100;
    int sign1=(msg->motor1 > 0) - (msg->motor1 < 0);
    int sign2=(msg->motor2 > 0) - (msg->motor2 < 0);
    int absolute1=abs(msg->motor1);
    int absolute2=abs(msg->motor2);
    int motor1Command;
    int motor2Command;
    if(msg->status){ //reset encoders not asked
      if(absolute1<=minimum_speed){//comes x100
        motor1Command=0;
      }else if (absolute1>=max_speed_possible)
      {
        motor1Command=sign1*(128-(msg->motor1>0));
      }else{
        if (sign1<0){
        //motor1Command=int(((msg->motor1/100-sign1*1.06905728)/1.91575185)*(128-(msg->motor1>0))/voltage_available);
          motor1Command=int(((-66.8145*(absolute1/100.0 + 1.069))/(voltage_available))-0.5);
          if(motor1Command >= int((-71.4279/voltage_available)-0.5)){
            motor1Command=0;
          }

        }else{
          motor1Command=int(((66.2925*(absolute1/100.0 + 1.069))/(voltage_available))+0.5);
          if(motor1Command <= int((70.87/voltage_available) +0.5)){
            motor1Command=0;
          }
        }
      }
      
      if(absolute2<=minimum_speed){//comes x100
        motor2Command=0;
      }else if (absolute2>=max_speed_possible)
      {
        motor2Command=sign1*(128-(msg->motor2>0));
      }else{
        if (sign2<0){
          //motor2Command=int(((msg->motor2/100-sign2*1.06905728)/1.91575185)*(128-(msg->motor2>0))/voltage_available);
          motor2Command=int(((-66.8145*(absolute2/100.0 + 1.069))/(voltage_available))-0.5);
          if(motor2Command >= int((-71.4279/voltage_available)-0.5)){
            motor2Command=0;
          }

        }else{
          motor2Command=int(((66.2925*(absolute2/100.0 + 1.069))/(voltage_available))+0.5);
          if(motor2Command <= int((70.87/voltage_available)+0.5)){
            motor2Command=0;
          }
        }      
      }
      if(whichMotorFirst){
        MD25.setMotor1Speed(motor1Command);
        MD25.setMotor2Speed(motor2Command);
        whichMotorFirst=false;
      }else{
        MD25.setMotor2Speed(motor2Command);
        MD25.setMotor1Speed(motor1Command);
        whichMotorFirst=true;
      }
      cycles_no_message=0;
      number_of_problems=0;
      previous_motorCommand_msg.motor1=msg->motor1;
      previous_motorCommand_msg.motor2=msg->motor2;
    }else{ //asked encoder reset
        stop_moving();
        encoder_reset_asked=true;
        cycles_no_message=0;
        number_of_problems=0;
        previous_motorCommand_msg.motor1=0;
        previous_motorCommand_msg.motor2=0;
    } 
  }else{
    //stop_moving();
  }
}
///////////

void setup() {

  pinMode(RED_PIN, OUTPUT);
  pinMode(GREEN_PIN, OUTPUT);
  pinMode(BLUE_PIN, OUTPUT);
  RGB_color(255,0,0);

  // Configure i2c transport
  Wire.begin();
  // Configure serial transport
  Serial.begin(115200);
  set_microros_serial_transports(Serial);

  setupMD25();
  setupIMU();

//MicroRos settings/initialization
  allocator = rcl_get_default_allocator();

  //create init_options
  RCCHECK(rclc_support_init(&support, 0, NULL, &allocator));

  // create node
  RCCHECK(rclc_node_init_default(&node, "micro_ros_node", "", &support));

  // create encoder ticks publisher
  RCCHECK(rclc_publisher_init_default(
    &enconderTicks_publisher,
    &node,
    ROSIDL_GET_MSG_TYPE_SUPPORT(traxter_msgs,msg,DualMotorArray),
    "traxter/encoder/ticks"));

  // create imu publisher
  RCCHECK(rclc_publisher_init_best_effort(
    &imu_publisher,
    &node,
    ROSIDL_GET_MSG_TYPE_SUPPORT(traxter_msgs,msg,LightImu),
    "traxter/imu/data/unprocessed"));

  // create encoder ticks and Current publish timer 50.0Hz
  const unsigned int encoderTicks_and_imu_timer_timeout = 20.0;
  RCCHECK(rclc_timer_init_default(
    &encoderTicks_and_imu_timer,
    &support,
    RCL_MS_TO_NS(encoderTicks_and_imu_timer_timeout),
    encoderTicks_and_imu_timer_callback));

  //create motorCommand_subscriber
    RCCHECK(rclc_subscription_init_default(
    &motorCommand_subscriber,
    &node,
    ROSIDL_GET_MSG_TYPE_SUPPORT(traxter_msgs,msg,DualMotorArray),
    "traxter/motor/command"));

  // create executor for encoderTicks publishing
  encoderTicks_and_imu_executor = rclc_executor_get_zero_initialized_executor();
  RCCHECK(rclc_executor_init(&encoderTicks_and_imu_executor, &support.context, 3, &allocator));
  RCCHECK(rclc_executor_add_timer(&encoderTicks_and_imu_executor, &encoderTicks_and_imu_timer));

  // create executor for motorCommand subscribing
  motorCommand_executor = rclc_executor_get_zero_initialized_executor();
  RCCHECK(rclc_executor_init(&motorCommand_executor, &support.context, 2, &allocator));
  RCCHECK(rclc_executor_add_subscription(
    &motorCommand_executor, &motorCommand_subscriber, &motorCommand_msg,
    &motorCommand_subscriber_callback, ON_NEW_DATA));

  // check if MD25 is connected
  isMD25connected=MD25.isBoardConnected();
  previous_motorCommand_msg.motor1=0.0;
  previous_motorCommand_msg.motor2=0.0;
}

void loop() {

  cycles_no_message+=1;
  if (cycles_no_message<300)
  {
    stopped_from_moving=false;
/*   }else if (cycles_no_message>100000){
    start_over(); */
  }else{
    stop_moving();
  }
  if (!isMD25connected){
    setupMD25();
  }

  RCSOFTCHECK(rclc_executor_spin_some(&motorCommand_executor, RCL_MS_TO_NS(0.5)));
  RCSOFTCHECK(rclc_executor_spin_some(&encoderTicks_and_imu_executor, RCL_MS_TO_NS(0.5)));
  //illuminate(); //TO UNCOMMENT WHEN AN LED IS CONNECTED

}
//ros2 run micro_ros_agent micro_ros_agent serial --dev /dev/ttyUSB0 -b 115200
//pio run --target clean_microros  # Clean library
//ros2 topic pub --rate 10 --qos-reliability best_effort  /traxter/motor/command traxter_msgs/msg/DualMotorArray "{motor1: 180, motor2: 180, status: 0}"
//RMW_IMPLEMENTATION=rmw_connextdds